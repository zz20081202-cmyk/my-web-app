package com.baccarat.v4

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Canvas
import android.view.View
import android.widget.*
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    data class Round(
        val result: String,
        val banker: List<String>,
        val player: List<String>,
        val prediction: String?,
        val probs: DoubleArray?
    )

    private val rounds = mutableListOf<Round>()
    private val weights = DoubleArray(9) { 0.0 }
    private val prefsName = "baccarat_v4"
    private lateinit var bankerInput: EditText
    private lateinit var playerInput: EditText
    private lateinit var summary: TextView
    private lateinit var predictionText: TextView
    private lateinit var roadView: RoadView
    private lateinit var modelText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadData()
        buildUi()
        refresh()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        scroll.addView(root)

        val title = TextView(this).apply {
            text = "百家樂 V4｜自動學習分析"
            textSize = 24f
            setTextColor(Color.BLACK)
            setPadding(0,0,0,18)
        }
        root.addView(title)

        val hint = TextView(this).apply {
            text = "輸入牌面，例如：莊 K 8　閒 7 2。模型會在每局結算後更新。"
            textSize = 14f
            setPadding(0,0,0,12)
        }
        root.addView(hint)

        bankerInput = EditText(this).apply {
            hint = "莊家牌：K 8"
            singleLine = true
        }
        playerInput = EditText(this).apply {
            hint = "閒家牌：7 2"
            singleLine = true
        }
        root.addView(bankerInput)
        root.addView(playerInput)

        val add = Button(this).apply {
            text = "輸入本局並學習"
            setOnClickListener { addRound() }
        }
        root.addView(add)

        val predict = Button(this).apply {
            text = "分析下一局"
            setOnClickListener { refreshPrediction() }
        }
        root.addView(predict)

        val reset = Button(this).apply {
            text = "重置模型與歷史"
            setOnClickListener {
                rounds.clear()
                for (i in weights.indices) weights[i] = 0.0
                saveData()
                refresh()
                Toast.makeText(this@MainActivity, "已重置", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(reset)

        summary = TextView(this).apply {
            textSize = 16f
            setPadding(0,16,0,8)
        }
        root.addView(summary)

        predictionText = TextView(this).apply {
            textSize = 18f
            setPadding(0,8,0,8)
        }
        root.addView(predictionText)

        modelText = TextView(this).apply {
            textSize = 14f
            setPadding(0,8,0,12)
        }
        root.addView(modelText)

        roadView = RoadView(this)
        root.addView(roadView, LinearLayout.LayoutParams(-1, 430))

        val recent = TextView(this).apply {
            textSize = 14f
            setPadding(0,12,0,20)
        }
        root.addView(recent)
        scroll.tag = recent

        setContentView(scroll)
    }

    private fun parseCards(s: String): List<String> =
        s.trim().uppercase().split(Regex("[,\\s]+")).filter { it.isNotBlank() }

    private fun cardValue(c: String): Int = when (c) {
        "A" -> 1
        "10","J","Q","K" -> 0
        else -> c.toIntOrNull()?.coerceIn(0,9) ?: -1
    }

    private fun total(cards: List<String>): Int =
        cards.map { cardValue(it) }.sum().mod(10)

    private fun valid(cards: List<String>): Boolean =
        cards.isNotEmpty() && cards.size in 2..3 && cards.all { cardValue(it) >= 0 }

    private fun outcome(b: Int, p: Int): String =
        when {
            b > p -> "莊"
            p > b -> "閒"
            else -> "和"
        }

    // Features: recent banker/player/tie proportions, streak, alternation,
    // momentum windows, and total sample size.
    private fun features(): DoubleArray {
        val f = DoubleArray(9)
        val n = rounds.size
        if (n == 0) return f
        fun prop(label: String, w: Int): Double {
            val xs = rounds.takeLast(min(w,n))
            return xs.count { it.result == label }.toDouble() / xs.size
        }
        f[0] = prop("莊", 5)
        f[1] = prop("閒", 5)
        f[2] = prop("和", 5)
        f[3] = prop("莊", 20)
        f[4] = prop("閒", 20)
        f[5] = prop("和", 20)
        val last = rounds.last().result
        var streak = 0
        for (r in rounds.asReversed()) {
            if (r.result == last) streak++ else break
        }
        f[6] = min(streak, 8) / 8.0
        val xs = rounds.takeLast(min(20,n))
        f[7] = if (xs.size < 2) 0.5 else
            xs.zipWithNext().count { it.first.result != it.second.result }.toDouble() / (xs.size-1)
        f[8] = min(n,100).toDouble()/100.0
        return f
    }

    private fun logits(f: DoubleArray): DoubleArray {
        // Separate class weight vectors encoded compactly for a lightweight
        // online softmax learner. This keeps the app dependency-free.
        val scores = DoubleArray(3)
        val priors = doubleArrayOf(0.458, 0.446, 0.096)
        for (c in 0..2) {
            var s = kotlin.math.ln(priors[c])
            for (i in f.indices) {
                val idx = c*3 + (i % 3)
                s += weights[idx] * f[i]
            }
            scores[c] = s
        }
        val m = scores.maxOrNull() ?: 0.0
        var sum = 0.0
        for (i in scores.indices) { scores[i] = exp(scores[i]-m); sum += scores[i] }
        for (i in scores.indices) scores[i] /= sum
        return scores
    }

    private fun predict(): Pair<String,DoubleArray> {
        val p = logits(features())
        val idx = p.indices.maxByOrNull { p[it] } ?: 0
        return arrayOf("莊","閒","和")[idx] to p
    }

    private fun learn(actual: String, probs: DoubleArray) {
        val f = features()
        val y = when(actual) { "莊"->0; "閒"->1; else->2 }
        val lr = 0.035
        val decay = 0.997
        for (i in weights.indices) weights[i] *= decay
        // Online multiclass update. Each class receives a gradient signal.
        for (c in 0..2) {
            val target = if (c == y) 1.0 else 0.0
            val err = target - probs[c]
            for (j in f.indices) {
                val idx = c*3 + (j % 3)
                weights[idx] += lr * err * f[j]
            }
        }
    }

    private fun addRound() {
        val b = parseCards(bankerInput.text.toString())
        val p = parseCards(playerInput.text.toString())
        if (!valid(b) || !valid(p)) {
            Toast.makeText(this, "請輸入 2～3 張有效牌面，例如 K 8 / 7 2", Toast.LENGTH_LONG).show()
            return
        }

        // Predict before adding actual result.
        val before = predict()
        val result = outcome(total(b), total(p))
        rounds.add(Round(result,b,p,before.first,before.second))
        learn(result,before.second)
        saveData()

        bankerInput.text.clear()
        playerInput.text.clear()
        refresh()

        Toast.makeText(this, "本局：$result｜模型原預測：${before.first}", Toast.LENGTH_SHORT).show()
    }

    private fun refreshPrediction() {
        if (rounds.isEmpty()) {
            predictionText.text = "尚無資料，先輸入幾局牌面。"
            return
        }
        val (pred,p) = predict()
        predictionText.text = "模型下一局分析：$pred\n莊 ${"%.1f".format(p[0]*100)}%　閒 ${"%.1f".format(p[1]*100)}%　和 ${"%.1f".format(p[2]*100)}%"
    }

    private fun refresh() {
        val n = rounds.size
        val b = rounds.count { it.result=="莊" }
        val p = rounds.count { it.result=="閒" }
        val t = rounds.count { it.result=="和" }
        summary.text = "總局數：$n\n莊：$b (${pct(b,n)})　閒：$p (${pct(p,n)})　和：$t (${pct(t,n)})"

        val evaluated = rounds.filter { it.prediction != null }
        val hit = evaluated.count { it.prediction == it.result }
        val recent100 = evaluated.takeLast(100)
        val hit100 = recent100.count { it.prediction == it.result }
        modelText.text = "模型學習：已更新 $n 次\n總命中率：${pct(hit,evaluated.size)}\n最近100局命中率：${pct(hit100,recent100.size)}\n注意：命中率不代表未來一定能預測成功。"

        refreshPrediction()
        roadView.invalidate()

        val scroll = findViewById<ScrollView>(android.R.id.content)?.getChildAt(0) as? ScrollView
        // Recent list is the final TextView under the root.
        val root = (findViewById<ScrollView>(android.R.id.content)?.getChildAt(0) as? LinearLayout)
        root?.let {
            val tv = it.getChildAt(it.childCount-1) as? TextView
            if (tv != null) {
                tv.text = "最近20局：\n" + rounds.takeLast(20).joinToString("  ") {
                    "${it.result}${if (it.prediction != null && it.prediction == it.result) "✓" else if (it.prediction != null) "×" else ""}"
                }
            }
        }
    }

    private fun pct(x:Int,n:Int):String = if(n==0) "0.0%" else "%.1f%%".format(x*100.0/n)

    private fun saveData() {
        val a = JSONArray()
        rounds.forEach {
            val o=JSONObject()
            o.put("r",it.result); o.put("b",it.banker.joinToString(" "))
            o.put("p",it.player.joinToString(" "))
            o.put("pred",it.prediction ?: "")
            if (it.probs != null) o.put("probs", it.probs.joinToString(","))
            a.put(o)
        }
        val w = weights.joinToString(",")
        getSharedPreferences(prefsName,0).edit().putString("rounds",a.toString()).putString("weights",w).apply()
    }

    private fun loadData() {
        val sp=getSharedPreferences(prefsName,0)
        val a=runCatching { JSONArray(sp.getString("rounds","[]")) }.getOrNull() ?: JSONArray()
        for(i in 0 until a.length()){
            val o=a.getJSONObject(i)
            val probs=o.optString("probs","").takeIf{it.isNotBlank()}?.split(",")?.mapNotNull{it.toDoubleOrNull()}?.toDoubleArray()
            rounds.add(Round(o.getString("r"),o.getString("b").split(" "),o.getString("p").split(" "),o.optString("pred","").ifBlank{null},probs))
        }
        sp.getString("weights","")?.split(",")?.forEachIndexed { i,s -> if(i<weights.size) weights[i]=s.toDoubleOrNull()?:0.0 }
    }

    inner class RoadView(ctx: Context): View(ctx) {
        private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            paint.style=Paint.Style.FILL
            paint.textSize=28f
            val cols=12; val rows=6
            val cw=width.toFloat()/cols; val rh=height.toFloat()/rows
            for(i in 0..cols) { paint.style=Paint.Style.STROKE; paint.color=0xFFE0E0E0.toInt(); c.drawLine(i*cw,0f,i*cw,height.toFloat(),paint) }
            for(i in 0..rows) c.drawLine(0f,i*rh,width.toFloat(),i*rh,paint)
            rounds.takeLast(cols*rows).forEachIndexed { idx,r ->
                val x=(idx%cols)*cw+cw/2
                val y=(idx/cols)*rh+rh/2
                paint.style=Paint.Style.FILL
                paint.color=when(r.result){"莊"->0xFFD32F2F.toInt();"閒"->0xFF1976D2.toInt();else->0xFF616161.toInt()}
                c.drawCircle(x,y,min(cw,rh)*.30f,paint)
                paint.color=Color.WHITE; paint.textAlign=Paint.Align.CENTER; paint.textSize=18f
                c.drawText(r.result,x,y+6,paint)
            }
        }
    }
}
